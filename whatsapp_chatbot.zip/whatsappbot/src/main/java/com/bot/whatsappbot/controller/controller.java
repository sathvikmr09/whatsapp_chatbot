package com.bot.whatsappbot.controller;

import com.bot.whatsappbot.service.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class controller {

    @Autowired
    private service chatbotService;

    @PostMapping("/webhook")
    public String receiveMessage(@RequestBody Map<String, String> payload) {
        String from = payload.get("from");
        String message = payload.get("message");

        System.out.println("Received from: " + from + ", message: " + message);

        String reply = chatbotService.handleMessage(from, message);
        return reply;
    }
}
