package com.bot.whatsappbot.service;

import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class service {

    public String handleMessage(String from, String message) {
        String reply;

        switch (message.trim().toLowerCase()) {
            case "hi":
                reply = "Hello! How can I help you?\n1. Location\n2. Contact\n3. Help";
                break;
            case "1":
                reply = "Location : Bengaluru, India.";
                break;
            case "2":
                reply = "Contact us at : "
                		+ "Phone : +91-7619382758 or Email : sathvikmr09@gmail.com";
                break;
            case "3":
                reply = "Help: Please type 'hi' to go to the menu";
                break;
            default:
                reply = "Invalid choice. Please type 'hi' ";
                break;
        }

        saveMessageToFirebase(from, message);
        return reply;
    }

    private void saveMessageToFirebase(String from, String message) {
        try {
            Firestore db = FirestoreClient.getFirestore();
            Map<String, Object> data = new HashMap<>();
            data.put("from", from);
            data.put("message", message);
            data.put("timestamp", System.currentTimeMillis());

            db.collection("messages").add(data);
            System.out.println("Message saved to Firebase.");
        } catch (Exception e) {
            System.err.println("Error saving to Firebase: " + e.getMessage());
        }
    }
}
